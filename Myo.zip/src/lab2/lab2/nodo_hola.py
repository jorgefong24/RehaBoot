#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
import numpy as np
import threading
import time
from pymyolinux.core.myo import MyoDongle
import matplotlib.pyplot as plt
import asyncio
import websockets

# Variables globales
emg_data = []
pose_data = []  # Para almacenar las poses
max_samples = 200  # Mantener los últimos 200 datos (20 segundos a 10 muestras por segundo)
num_poses = 4  # Número de poses a capturar
pose_duration = 5  # Duración de cada pose en segundos
sampling_rate = 10  # Muestras por segundo

# Configuración del WebSocket
ESP32_IP = "ws://192.168.43.19:81"
RECEIVE_TIMEOUT = 5  # Tiempo en segundos para esperar la respuesta


async def send_command_once(command):
    """
    Envía un comando a través del WebSocket al ESP32.
    """
    try:
        async with websockets.connect(ESP32_IP) as websocket:
            await websocket.send(command)
            print(f"Número {command} enviado.")
            try:
                response = await asyncio.wait_for(websocket.recv(), timeout=RECEIVE_TIMEOUT)
                print(f"Respuesta de la ESP32: {response}")
            except asyncio.TimeoutError:
                print("No se recibió respuesta dentro del tiempo límite.")
    except Exception as e:
        print(f"Error al enviar el comando: {e}")


class PoseCaptureNode(Node):
    def __init__(self):
        super().__init__('pose_capture_node')
        self.pose_publisher = self.create_publisher(Float64MultiArray, 'pose_publisher', 10)

        try:
            # Conexión al dispositivo Myo
            self.device_1 = MyoDongle("/dev/ttyACM0")
            self.device_1.clear_state()

            myo_devices = self.device_1.discover_myo_devices()
            if len(myo_devices) > 0:
                self.device_1.connect(myo_devices[0])
                self.get_logger().info("Myo conectado exitosamente.")
            else:
                self.get_logger().error("No se encontraron dispositivos Myo, saliendo...")
                exit()

            # Configurar para leer datos del IMU y las señales EMG
            self.device_1.enable_imu_readings()
            self.device_1.enable_emg_readings()
            self.device_1.add_joint_emg_imu_handler(self.joint_event_handler)

            # Iniciar hilo de recepción de datos
            self.data_thread = threading.Thread(target=self.receive_data, args=(self.device_1,))
            self.data_thread.daemon = True
            self.data_thread.start()

            self.get_logger().info("Nodo ROS2 para captura de poses iniciado.")

        except Exception as e:
            self.get_logger().error(f"Error inicializando Myo: {e}")
            exit()

    def joint_event_handler(self, emg_list, orient_w, orient_x, orient_y, orient_z,
                            accel_1, accel_2, accel_3, gyro_1, gyro_2, gyro_3, sample_num):
        global emg_data
        emg_data.append(emg_list)
        
        if len(emg_data) > max_samples:
            emg_data.pop(0)  # Eliminar el primer elemento si la longitud excede max_samples

    def receive_data(self, device_1):
        while True:
            try:
                device_1.scan_for_data_packets(3)
                time.sleep(0.1)
            except Exception as e:
                self.get_logger().error(f"Error recibiendo datos: {e}")
                break

    def capture_pose(self, pose_id):
        global emg_data, pose_data
        pose_samples = []
        self.get_logger().info(f"Capturando pose {pose_id + 1}... Por favor mantén la pose durante {pose_duration} segundos.")
        
        start_time = time.time()
        while time.time() - start_time < pose_duration:
            time.sleep(0.1)
            if len(emg_data) > 0:
                pose_samples.append(np.array(emg_data[-1]))
                emg_data = []  # Limpiar después de capturar datos
        
        pose_data.append(np.array(pose_samples))  # Guardar los datos de la pose
        self.get_logger().info(f"Pose {pose_id + 1} capturada.")

    def extract_features(self, pose):
        mean_values = np.mean(pose, axis=0)
        std_values = np.std(pose, axis=0)
        return np.concatenate((mean_values, std_values))

    def compare_poses(self, current_pose):
        global pose_data
        current_features = self.extract_features(current_pose)
        
        similarities = []
        for stored_pose in pose_data:
            stored_features = self.extract_features(stored_pose)
            similarity = np.linalg.norm(current_features - stored_features)
            similarities.append(similarity)

        best_match_idx = np.argmin(similarities)
        return best_match_idx

    async def handle_detected_pose(self, pose_id):
        """
        Envia un comando basado en la pose detectada.
        """
        commands = ['1', '2', '3', '4']  # Comandos para las poses
        if 0 <= pose_id < len(commands):
            command = commands[pose_id]
            await send_command_once(command)

    def run(self):
        global pose_data
        for pose_id in range(num_poses):
            self.capture_pose(pose_id)

        try:
            while True:
                current_pose = np.array(emg_data[-max_samples:])
                if len(current_pose) > 0:
                    detected_pose = self.compare_poses(current_pose)
                    self.get_logger().info(f"Pose detectada: {detected_pose + 1}")
                    
                    # Manejar pose detectada
                    asyncio.run(self.handle_detected_pose(detected_pose))

        except KeyboardInterrupt:
            self.get_logger().info("Saliendo...")

def main(args=None):
    rclpy.init(args=args)
    node = PoseCaptureNode()
    try:
        node.run()
    except Exception as e:
        node.get_logger().error(f"Error ejecutando el nodo: {e}")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
