import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray


class PoseSubscriberNode(Node):
    def __init__(self):
        super().__init__('pose_subscriber_node')
        self.pose_subscription = self.create_subscription(
            Float64MultiArray,
            'pose_publisher',
            self.pose_callback,
            10
        )
        self.get_logger().info("Nodo ROS2 suscriptor de poses iniciado.")

    def pose_callback(self, msg):
        """
        Callback que se ejecuta cuando se recibe un mensaje en el tópico 'pose_publisher'.
        """
        self.get_logger().info(f"Pose recibida: {msg.data}")


def main(args=None):
    rclpy.init(args=args)
    node = PoseSubscriberNode()
    try:
        rclpy.spin(node)  # Procesa callbacks continuamente
    except KeyboardInterrupt:
        node.get_logger().info("Nodo detenido manualmente.")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
