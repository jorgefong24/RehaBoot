from setuptools import setup

package_name = 'lab2'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='sebastian',
    maintainer_email='sebastian@example.com',
    description='Paquete para captura y suscripción de poses.',
    license='Apache License 2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'py_node = lab2.nodo_hola:main',  # Nodo publicador
            'py_subscriber = lab2.pose_subscriber:main',  # Nodo suscriptor
        ],
    },
)
